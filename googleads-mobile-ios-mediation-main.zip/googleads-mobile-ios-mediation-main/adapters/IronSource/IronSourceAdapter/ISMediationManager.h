// Copyright 2019 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import <IronSource/IronSource.h>
#import "GADMAdapterIronSourceInterstitialDelegate.h"
#import "GADMAdapterIronSourceRewardedDelegate.h"

@interface ISMediationManager
    : NSObject <ISDemandOnlyRewardedVideoDelegate, ISDemandOnlyInterstitialDelegate>

+ (nonnull instancetype)sharedManager;
- (void)initIronSourceSDKWithAppKey:(nonnull NSString *)appKey forAdUnits:(nonnull NSSet *)adUnits;
- (void)loadRewardedAdWithDelegate:(nonnull id<GADMAdapterIronSourceRewardedDelegate>)delegate
                        instanceID:(nonnull NSString *)instanceID;

- (void)presentRewardedAdFromViewController:(nonnull UIViewController *)viewController
                                 instanceID:(nonnull NSString *)instanceID;

- (void)loadInterstitialAdWithDelegate:
            (nonnull id<GADMAdapterIronSourceInterstitialDelegate>)delegate
                            instanceID:(nonnull NSString *)instanceID;

- (void)presentInterstitialAdFromViewController:(nonnull UIViewController *)viewController
                                     instanceID:(nonnull NSString *)instanceID;

@end
