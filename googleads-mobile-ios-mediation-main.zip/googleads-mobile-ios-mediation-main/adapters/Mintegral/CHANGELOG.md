## Mintegral iOS Mediation Adapter Changelog

#### Next Version

- Initial release!

Built and tested with:
- Google Mobile Ads SDK version 9.8.0.
- Mintegral SDK version 7.1.9.0.
