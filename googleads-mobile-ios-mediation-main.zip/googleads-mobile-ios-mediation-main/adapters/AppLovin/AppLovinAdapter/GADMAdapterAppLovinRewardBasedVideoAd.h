//
//  GADMAdapterAppLovinRewardBasedVideoAd.h
//
//
//  Created by Thomas So on 5/20/17.
//
//

#import <GoogleMobileAds/GoogleMobileAds.h>

@interface GADMAdapterAppLovinRewardBasedVideoAd : NSObject

@end
