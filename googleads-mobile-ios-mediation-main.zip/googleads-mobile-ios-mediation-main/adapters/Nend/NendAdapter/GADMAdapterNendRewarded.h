//
//  GADMAdapterNendRewarded.h
//  NendAdapter
//
//  Copyright © 2017 FAN Communications. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>

@interface GADMAdapterNendRewarded : NSObject

@end
