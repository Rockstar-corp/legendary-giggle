//
//  GADMAdapterNend.h
//  NendAdapter
//
//  Copyright © 2017 FAN Communications. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>

@interface GADMAdapterNend : NSObject <GADMAdNetworkAdapter>
@end
