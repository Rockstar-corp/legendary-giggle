## Zucks iOS Mediation Adapter Changelog

#### Next Version
- Initial release!
- Supports banner, interstitial and rewarded ads.

Built and tested with:
- Google Mobile Ads SDK version x.y.z.
- Zucks SDK version x.y.z.
