# Pangle Mediation Adapter for Google Mobile Ads SDK for iOS

This is an adapter to be used in conjunction with the Google Mobile Ads SDK.
