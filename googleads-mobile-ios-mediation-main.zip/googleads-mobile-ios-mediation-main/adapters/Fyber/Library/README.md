Static library and Framework will be generated in this folder.
