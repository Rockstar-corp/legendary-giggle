# myTarget Mediation Adapter for Google Mobile Ads SDK for iOS

This is an adapter to be used in conjunction with the Google Mobile Ads SDK.
For requirements, instructions, and other info, see the
[myTarget Adapter Integration Guide](https://developers.google.com/admob/ios/mediation/mytarget).

See the [changelog](https://developers.google.com/admob/ios/mediation/mytarget#mytarget-ios-mediation-adapter-changelog)
to view the version history.
