Drop all necessary frameworks in this folder. Don’t link them to any target in
Xcode project.