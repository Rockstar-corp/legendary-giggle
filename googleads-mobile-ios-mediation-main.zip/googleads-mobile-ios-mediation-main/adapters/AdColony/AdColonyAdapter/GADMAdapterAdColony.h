//
// Copyright 2016, AdColony, Inc.
//

#import <GoogleMobileAds/GoogleMobileAds.h>

@interface GADMAdapterAdColony : NSObject <GADMAdNetworkAdapter>

@end
