//
// Copyright 2016, AdColony, Inc.
//

#import "GADMAdapterAdColonyExtras.h"

@implementation GADMAdapterAdColonyExtras

@end
