#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <AdColonyAdapter/GADMAdapterAdColonyExtras.h>
#import <AdColonyAdapter/GADMediationAdapterAdColony.h>
